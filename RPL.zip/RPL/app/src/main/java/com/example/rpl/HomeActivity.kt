package com.example.rpl

import android.content.Intent
import android.os.Bundle
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import com.example.rpl.menu.account.Account


class HomeActivity : AppCompatActivity() {

    lateinit var btnSetting: ImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        btnSetting = findViewById(R.id.setting)

        btnSetting.setOnClickListener {
            startActivity(Intent(this, Account::class.java))
        }


    }
}