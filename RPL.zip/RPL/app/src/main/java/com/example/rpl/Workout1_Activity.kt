package com.example.rpl

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Workout1_Activity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_workout1)
    }
}