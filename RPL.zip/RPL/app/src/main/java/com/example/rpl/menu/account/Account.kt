package com.example.rpl.menu.account

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.rpl.HomeActivity
import com.example.rpl.R
import com.example.rpl.autentikasi.LoginActivity
import com.google.firebase.auth.FirebaseAuth


class Account : AppCompatActivity() {
    lateinit var textUser: TextView
    lateinit var textemail: TextView
    lateinit var btnLogout: Button
    lateinit var btnHome: ImageView

    val firebaseAuth = FirebaseAuth.getInstance()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_account)

        btnLogout = findViewById(R.id.logout)
        textUser = findViewById(R.id.UsernameAcc)
        btnHome = findViewById(R.id.home)

        btnHome.setOnClickListener {
            startActivity(Intent(this, HomeActivity::class.java))
        }
        val firebaseUser = firebaseAuth.currentUser
        if (firebaseUser!=null){
            textUser.text = firebaseUser.displayName

        }else{
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }
    }

}